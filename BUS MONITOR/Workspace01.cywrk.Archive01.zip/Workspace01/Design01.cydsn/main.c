/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "main.h"

/*******************************************************************************
* File Name: main.c
*
* Version: 2.0
*
* Description:
*   The component is enumerated as a Virtual Com port. Receives data from the 
*   hyper terminal, then sends back the received data.
*   For PSoC3/PSoC5LP, the LCD shows the line settings.
*
* Related Document:
*  Universal Serial Bus Specification Revision 2.0
*  Universal Serial Bus Class Definitions for Communications Devices
*  Revision 1.2
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <project.h>
#include "stdio.h"
#include "mdZ80.h"

#if defined (__GNUC__)
    /* Add an explicit reference to the floating point printf library */
    /* to allow usage of the floating point conversion specifiers. */
    /* This is not linked in by default with the newlib-nano library. */
    asm (".global _printf_float");
#endif

struct IntrBuf Atable[MAXTABLE];
uint Atable_ctr = 0;
uint LimitMode = 0;

#define USBFS_DEVICE    (0u)
#define USBUART_BUFFER_SIZE (64u)

reg8 *ptrs[] = {
    Status_Reg_ADH_Status_PTR,
    Status_Reg_ADL_Status_PTR,
    Status_Reg_DI_Status_PTR,
    Status_Reg_BUS_Status_PTR,
    Status_Reg_BUS2_Status_PTR,
};
    

void UARTsend(char *str)
{    
    /* Service USB CDC when device is configured. */
    if (0u != USBUART_GetConfiguration())
    {    
        uint16 count = strlen(str);
        if (0u != count)
        {
            /* Wait until component is ready to send data to host. */
            while (0u == USBUART_CDCIsReady())
            {
            }

            /* Send data back to host. */
            USBUART_PutData((uint8 *)str, count);

            /* If the last sent packet is exactly the maximum packet 
            *  size, it is followed by a zero-length packet to assure
            *  that the end of the segment is properly identified by 
            *  the terminal.
            */
            if (USBUART_BUFFER_SIZE == count)
            {
                /* Wait until component is ready to send data to PC. */
                while (0u == USBUART_CDCIsReady())
                {
                }

                /* Send zero-length packet to PC. */
                USBUART_PutData(NULL, 0u);
            }
        }
    }
}

int hextoint(char c)
{
    if ((c >= '0') && (c <= '9')){
        return c - '0';
    }
    if ((c >= 'A') && (c <= 'F')){
        return 10 + c - 'A';
    }
    if ((c >= 'a') && (c <= 'f')){
        return 10 + c - 'a';
    }
    return 0;
}

int getnum(char *str,int count)
{
    int val = 0;
    for (int i=1;i<count;i++){
        if (str[i] <= ' ') continue;
        val <<= 4;
        val += hextoint(str[i]);
    }
    return val;
}

/* Defines for DMA_1 */
#define DMA_1_BYTES_PER_BURST 1
#define DMA_1_REQUEST_PER_BURST 1
#define DMA_1_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_1_DST_BASE (CYDEV_SRAM_BASE)

/* Variable declarations for DMA_1 */
/* Move these variable declarations to the top of the function */
uint8 DMA_1_Chan;
uint8 DMA_1_TD[1];

uint8 MEMBUF[1024];

void DMAInit()
{
    /* DMA Configuration for DMA_1 */
    DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
        HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
    DMA_1_TD[0] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_1_TD[0], sizeof(MEMBUF), CY_DMA_DISABLE_TD, CY_DMA_TD_INC_DST_ADR);
    CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)Status_Reg_DI_Status_PTR), LO16((uint32)MEMBUF));
    CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
    CyDmaChEnable(DMA_1_Chan, 1);
}

void RunCommand(char *str,uint16 count)
{
    char buf[256];
    // SET DELIM
    str[count] = 0x00;
    switch(str[0])
    {
        case 'R':
        case 'r':
        {
            uint8 stat1 = Status_Reg_DI_Read();
            sprintf(buf,"D[7:0]:%02X\r\n",stat1);
            UARTsend(buf);
        }
        break;
        
        case 'W':
        case 'w':
        {
            int val = getnum(str,count);
            sprintf(buf,"SET CTRL TO %02X\r\n",val);
            Control_Reg_DO_Write(val & 0xFF);
            UARTsend(buf);
        }
        break;

        /*
        case 'T':
        case 't':
        {
            sprintf(buf,"DMA RESET\r\n");
            DMAInit();
            UARTsend(buf);
        }
        break;
        */
        
        case 'P':
        case 'p':
        {
            for (uint i=0;i<sizeof(ptrs)/sizeof(reg8*);i++){
                sprintf(buf,"%08X\r\n",
                    (uint)ptrs[i]);
                UARTsend(buf);
            }
        } 
        break;

        case 'T':
        case 't':
        {
            uint capt = Timer_1_ReadCapture();
            uint peri = Timer_1_ReadPeriod();
            sprintf(buf,"Timer : %08X\r\n",peri-capt);
            UARTsend(buf);
        } 
        break;
        
        
        case 'D':
        case 'd':
        {
            for (uint i=0;i<sizeof(MEMBUF);i+=16){
                sprintf(buf,"%04X : %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X\r\n",
                    i,
                    MEMBUF[i+0],
                    MEMBUF[i+1],
                    MEMBUF[i+2],
                    MEMBUF[i+3],
                    MEMBUF[i+4],
                    MEMBUF[i+5],
                    MEMBUF[i+6],
                    MEMBUF[i+7],
                    MEMBUF[i+8],
                    MEMBUF[i+9],
                    MEMBUF[i+10],
                    MEMBUF[i+11],
                    MEMBUF[i+12],
                    MEMBUF[i+13],
                    MEMBUF[i+14],
                    MEMBUF[i+15]);
                UARTsend(buf);
            }
        }
        break;

        case '*':
        case '=':
        {
            uint passnext = 0;
            isr_MEMWR_Disable(); // Stop INT
            Control_Reg_WAIT_Control = 0x02; // DISABLE WAIT
            
            sprintf(buf,"-- TRACE LOG --\r\n");            
            UARTsend(buf);
            
            
            if (Atable_ctr >= MAXTABLE) {
            for (uint i=Atable_ctr & (MAXTABLE-1);i<MAXTABLE;i++){
                uint8 bus2 = ~(Atable[i].bus2);
                //uint8 bus1 = ~(Atable[i].bus1);

                if ((bus2 & M1) && (passnext == 0)) {
                    uchar insts[16];
                    uint j = i;
                    insts[0] = Atable[j].data;
                    j = (j+1) & (MAXTABLE - 1) ;
                    insts[1] = Atable[j].data;
                    j = (j+1) & (MAXTABLE - 1) ;
                    insts[2] = Atable[j].data;
                    j = (j+1) & (MAXTABLE - 1) ;
                    insts[3] = Atable[j].data;
                    j = disasmZ80( insts, Atable[i].addr,0, buf, INTEL, 0 );
                    UARTsend(buf);
                    // 2バイト命令のときは１バイト飛ばす
                    passnext = 0;
                    if (disz80[0][insts[0]].len<0) {
                        passnext = 1;
                    }
                } else {
                    passnext = 0;
                }

                if (str[0] == '*') {
                sprintf(buf,"%08X : %04X %02X %s %s %s %s %s\r\n",
                    (Atable_ctr - (Atable_ctr & (MAXTABLE-1))) + i - MAXTABLE,
                    Atable[i].addr,
                    Atable[i].data,
                    ((bus2 & MREQ)  ? "MR" : "__"),
                    ((bus2 & IOREQ) ? "IO" : "__"),
                    ((bus2 & M1)    ? "M1" : "__"),
                    ((bus2 & RD)    ? "RD" : "__"),
                    ((bus2 & WR)    ? "WR" : "__")
                );
                UARTsend(buf);
                }
            }
            }           

            //sprintf(buf,"-- --\r\n");            
            //UARTsend(buf);
            for (uint i=0;i<(Atable_ctr & (MAXTABLE-1));i++){
                uint8 bus2 = ~(Atable[i].bus2);
                //uint8 bus1 = ~(Atable[i].bus1);
                if ((bus2 & M1) && (passnext == 0)) {
                    uchar insts[16];
                    uint j = i;
                    insts[0] = Atable[j].data;
                    j = (j+1) & (MAXTABLE - 1) ;
                    insts[1] = Atable[j].data;
                    j = (j+1) & (MAXTABLE - 1) ;
                    insts[2] = Atable[j].data;
                    j = (j+1) & (MAXTABLE - 1) ;
                    insts[3] = Atable[j].data;
                    j = disasmZ80( insts, Atable[i].addr,0, buf, INTEL, 0 );
                    UARTsend(buf);
                    
                    // 2バイト命令のときは１バイト飛ばす
                    passnext = 0;
                    if (disz80[0][insts[0]].len<0) {
                        passnext = 1;
                    }
                } else {
                    passnext = 0;
                }

                if (str[0] == '*') {
                sprintf(buf,"%08X : %04X %02X %s %s %s %s %s\r\n",
                    (Atable_ctr - (Atable_ctr & (MAXTABLE-1))) + i - MAXTABLE,
                    Atable[i].addr,
                    Atable[i].data,
                    ((bus2 & MREQ)  ? "MR" : "__"),
                    ((bus2 & IOREQ) ? "IO" : "__"),
                    ((bus2 & M1)    ? "M1" : "__"),
                    ((bus2 & RD)    ? "RD" : "__"),
                    ((bus2 & WR)    ? "WR" : "__")
                );
                UARTsend(buf);
                }
            }
            
            Control_Reg_WAIT_Control = 0x00; // ENABLE WAIT
            isr_MEMWR_Enable(); // Start Int
        }
        break;
        
        case '-':
            {
                sprintf(buf,"COUNT RESET\r\n");
                Atable_ctr = 0;
                UARTsend(buf);
            }
            break;
        
        case 'L':
            {
                isr_MEMWR_Disable(); // Stop INT
                Control_Reg_WAIT_Control = 0x02; // DISABLE WAIT
                //
                sprintf(buf,"LIMIT MODE : COUNT RESET\r\n");
                LimitMode = 1;
                Atable_ctr = 0;
                UARTsend(buf);
                //
                Control_Reg_WAIT_Control = 0x00; // ENABLE WAIT
                isr_MEMWR_Enable(); // Start Int
            }
            break;
            
                
        default:
            sprintf(buf,"R,W[XX],T,D,*,=,-,L - UNKNOWN COMMAND:%s\r\n",str);
            UARTsend(buf);
        break;
    }
}

/*******************************************************************************
* Function Name: main
********************************************************************************/
#define CMDLINE_LEN (256)
int main()
{
    uint16 count;
    uint8 buffer[USBUART_BUFFER_SIZE];
    uint8  cmdline[CMDLINE_LEN];
    uint16 cmdcount = 0;
          
    //DMAInit();    
    
    isr_MEMWR_Start();
    Timer_1_Start();
    CyGlobalIntEnable;

    /* Start USBFS operation with 5-V operation. */
    USBUART_Start(USBFS_DEVICE, USBUART_5V_OPERATION);
    for(;;)
    {
        CyPmAltAct(PM_ALT_ACT_TIME_NONE,PM_ALT_ACT_SRC_INTERRUPT);
            
        /* Host can send double SET_INTERFACE request. */
        if (0u != USBUART_IsConfigurationChanged())
        {
            /* Initialize IN endpoints when device is configured. */
            if (0u != USBUART_GetConfiguration())
            {
                /* Enumeration is done, enable OUT endpoint to receive data 
                 * from host. */
                USBUART_CDC_Init();
            }
        }

        /* Service USB CDC when device is configured. */
        if (0u != USBUART_GetConfiguration())
        {
            /* Check for input data from host. */
            if (0u != USBUART_DataIsReady())
            {
                /* Read received data and re-enable OUT endpoint. */
                count = USBUART_GetAll(buffer);
                if (count > 0) {
                    if (cmdcount+count < CMDLINE_LEN-1) {
                        for(int i=0 ;i<count;i++){
                            cmdline[cmdcount+i] = buffer[i];
                        }
                        cmdcount += count;
                        if (cmdline[cmdcount-1] < ' ') {
                            RunCommand((char *)cmdline,cmdcount);
                            cmdcount = 0 ;
                        }
                    } else {
                        UARTsend("?COMMAND ERROR\n");
                    }
                }
            }
        }
    }
}


/* [] END OF FILE */
