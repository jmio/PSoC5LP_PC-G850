/*******************************************************************************
* File Name: nMREQ.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_nMREQ_H) /* Pins nMREQ_H */
#define CY_PINS_nMREQ_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "nMREQ_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 nMREQ__PORT == 15 && ((nMREQ__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    nMREQ_Write(uint8 value);
void    nMREQ_SetDriveMode(uint8 mode);
uint8   nMREQ_ReadDataReg(void);
uint8   nMREQ_Read(void);
void    nMREQ_SetInterruptMode(uint16 position, uint16 mode);
uint8   nMREQ_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the nMREQ_SetDriveMode() function.
     *  @{
     */
        #define nMREQ_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define nMREQ_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define nMREQ_DM_RES_UP          PIN_DM_RES_UP
        #define nMREQ_DM_RES_DWN         PIN_DM_RES_DWN
        #define nMREQ_DM_OD_LO           PIN_DM_OD_LO
        #define nMREQ_DM_OD_HI           PIN_DM_OD_HI
        #define nMREQ_DM_STRONG          PIN_DM_STRONG
        #define nMREQ_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define nMREQ_MASK               nMREQ__MASK
#define nMREQ_SHIFT              nMREQ__SHIFT
#define nMREQ_WIDTH              1u

/* Interrupt constants */
#if defined(nMREQ__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in nMREQ_SetInterruptMode() function.
     *  @{
     */
        #define nMREQ_INTR_NONE      (uint16)(0x0000u)
        #define nMREQ_INTR_RISING    (uint16)(0x0001u)
        #define nMREQ_INTR_FALLING   (uint16)(0x0002u)
        #define nMREQ_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define nMREQ_INTR_MASK      (0x01u) 
#endif /* (nMREQ__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define nMREQ_PS                     (* (reg8 *) nMREQ__PS)
/* Data Register */
#define nMREQ_DR                     (* (reg8 *) nMREQ__DR)
/* Port Number */
#define nMREQ_PRT_NUM                (* (reg8 *) nMREQ__PRT) 
/* Connect to Analog Globals */                                                  
#define nMREQ_AG                     (* (reg8 *) nMREQ__AG)                       
/* Analog MUX bux enable */
#define nMREQ_AMUX                   (* (reg8 *) nMREQ__AMUX) 
/* Bidirectional Enable */                                                        
#define nMREQ_BIE                    (* (reg8 *) nMREQ__BIE)
/* Bit-mask for Aliased Register Access */
#define nMREQ_BIT_MASK               (* (reg8 *) nMREQ__BIT_MASK)
/* Bypass Enable */
#define nMREQ_BYP                    (* (reg8 *) nMREQ__BYP)
/* Port wide control signals */                                                   
#define nMREQ_CTL                    (* (reg8 *) nMREQ__CTL)
/* Drive Modes */
#define nMREQ_DM0                    (* (reg8 *) nMREQ__DM0) 
#define nMREQ_DM1                    (* (reg8 *) nMREQ__DM1)
#define nMREQ_DM2                    (* (reg8 *) nMREQ__DM2) 
/* Input Buffer Disable Override */
#define nMREQ_INP_DIS                (* (reg8 *) nMREQ__INP_DIS)
/* LCD Common or Segment Drive */
#define nMREQ_LCD_COM_SEG            (* (reg8 *) nMREQ__LCD_COM_SEG)
/* Enable Segment LCD */
#define nMREQ_LCD_EN                 (* (reg8 *) nMREQ__LCD_EN)
/* Slew Rate Control */
#define nMREQ_SLW                    (* (reg8 *) nMREQ__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define nMREQ_PRTDSI__CAPS_SEL       (* (reg8 *) nMREQ__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define nMREQ_PRTDSI__DBL_SYNC_IN    (* (reg8 *) nMREQ__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define nMREQ_PRTDSI__OE_SEL0        (* (reg8 *) nMREQ__PRTDSI__OE_SEL0) 
#define nMREQ_PRTDSI__OE_SEL1        (* (reg8 *) nMREQ__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define nMREQ_PRTDSI__OUT_SEL0       (* (reg8 *) nMREQ__PRTDSI__OUT_SEL0) 
#define nMREQ_PRTDSI__OUT_SEL1       (* (reg8 *) nMREQ__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define nMREQ_PRTDSI__SYNC_OUT       (* (reg8 *) nMREQ__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(nMREQ__SIO_CFG)
    #define nMREQ_SIO_HYST_EN        (* (reg8 *) nMREQ__SIO_HYST_EN)
    #define nMREQ_SIO_REG_HIFREQ     (* (reg8 *) nMREQ__SIO_REG_HIFREQ)
    #define nMREQ_SIO_CFG            (* (reg8 *) nMREQ__SIO_CFG)
    #define nMREQ_SIO_DIFF           (* (reg8 *) nMREQ__SIO_DIFF)
#endif /* (nMREQ__SIO_CFG) */

/* Interrupt Registers */
#if defined(nMREQ__INTSTAT)
    #define nMREQ_INTSTAT            (* (reg8 *) nMREQ__INTSTAT)
    #define nMREQ_SNAP               (* (reg8 *) nMREQ__SNAP)
    
	#define nMREQ_0_INTTYPE_REG 		(* (reg8 *) nMREQ__0__INTTYPE)
#endif /* (nMREQ__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_nMREQ_H */


/* [] END OF FILE */
