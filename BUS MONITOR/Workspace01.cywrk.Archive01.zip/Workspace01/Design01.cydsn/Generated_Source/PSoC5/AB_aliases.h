/*******************************************************************************
* File Name: AB.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AB_ALIASES_H) /* Pins AB_ALIASES_H */
#define CY_PINS_AB_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define AB_0			(AB__0__PC)
#define AB_0_INTR	((uint16)((uint16)0x0001u << AB__0__SHIFT))

#define AB_1			(AB__1__PC)
#define AB_1_INTR	((uint16)((uint16)0x0001u << AB__1__SHIFT))

#define AB_2			(AB__2__PC)
#define AB_2_INTR	((uint16)((uint16)0x0001u << AB__2__SHIFT))

#define AB_3			(AB__3__PC)
#define AB_3_INTR	((uint16)((uint16)0x0001u << AB__3__SHIFT))

#define AB_4			(AB__4__PC)
#define AB_4_INTR	((uint16)((uint16)0x0001u << AB__4__SHIFT))

#define AB_5			(AB__5__PC)
#define AB_5_INTR	((uint16)((uint16)0x0001u << AB__5__SHIFT))

#define AB_6			(AB__6__PC)
#define AB_6_INTR	((uint16)((uint16)0x0001u << AB__6__SHIFT))

#define AB_7			(AB__7__PC)
#define AB_7_INTR	((uint16)((uint16)0x0001u << AB__7__SHIFT))

#define AB_8			(AB__8__PC)
#define AB_8_INTR	((uint16)((uint16)0x0001u << AB__8__SHIFT))

#define AB_9			(AB__9__PC)
#define AB_9_INTR	((uint16)((uint16)0x0001u << AB__9__SHIFT))

#define AB_10			(AB__10__PC)
#define AB_10_INTR	((uint16)((uint16)0x0001u << AB__10__SHIFT))

#define AB_11			(AB__11__PC)
#define AB_11_INTR	((uint16)((uint16)0x0001u << AB__11__SHIFT))

#define AB_12			(AB__12__PC)
#define AB_12_INTR	((uint16)((uint16)0x0001u << AB__12__SHIFT))

#define AB_13			(AB__13__PC)
#define AB_13_INTR	((uint16)((uint16)0x0001u << AB__13__SHIFT))

#define AB_14			(AB__14__PC)
#define AB_14_INTR	((uint16)((uint16)0x0001u << AB__14__SHIFT))

#define AB_15			(AB__15__PC)
#define AB_15_INTR	((uint16)((uint16)0x0001u << AB__15__SHIFT))

#define AB_INTR_ALL	 ((uint16)(AB_0_INTR| AB_1_INTR| AB_2_INTR| AB_3_INTR| AB_4_INTR| AB_5_INTR| AB_6_INTR| AB_7_INTR| AB_8_INTR| AB_9_INTR| AB_10_INTR| AB_11_INTR| AB_12_INTR| AB_13_INTR| AB_14_INTR| AB_15_INTR))

#endif /* End Pins AB_ALIASES_H */


/* [] END OF FILE */
