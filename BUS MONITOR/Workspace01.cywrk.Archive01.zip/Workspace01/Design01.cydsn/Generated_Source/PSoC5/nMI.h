/*******************************************************************************
* File Name: nMI.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_nMI_H) /* Pins nMI_H */
#define CY_PINS_nMI_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "nMI_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 nMI__PORT == 15 && ((nMI__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    nMI_Write(uint8 value);
void    nMI_SetDriveMode(uint8 mode);
uint8   nMI_ReadDataReg(void);
uint8   nMI_Read(void);
void    nMI_SetInterruptMode(uint16 position, uint16 mode);
uint8   nMI_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the nMI_SetDriveMode() function.
     *  @{
     */
        #define nMI_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define nMI_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define nMI_DM_RES_UP          PIN_DM_RES_UP
        #define nMI_DM_RES_DWN         PIN_DM_RES_DWN
        #define nMI_DM_OD_LO           PIN_DM_OD_LO
        #define nMI_DM_OD_HI           PIN_DM_OD_HI
        #define nMI_DM_STRONG          PIN_DM_STRONG
        #define nMI_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define nMI_MASK               nMI__MASK
#define nMI_SHIFT              nMI__SHIFT
#define nMI_WIDTH              1u

/* Interrupt constants */
#if defined(nMI__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in nMI_SetInterruptMode() function.
     *  @{
     */
        #define nMI_INTR_NONE      (uint16)(0x0000u)
        #define nMI_INTR_RISING    (uint16)(0x0001u)
        #define nMI_INTR_FALLING   (uint16)(0x0002u)
        #define nMI_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define nMI_INTR_MASK      (0x01u) 
#endif /* (nMI__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define nMI_PS                     (* (reg8 *) nMI__PS)
/* Data Register */
#define nMI_DR                     (* (reg8 *) nMI__DR)
/* Port Number */
#define nMI_PRT_NUM                (* (reg8 *) nMI__PRT) 
/* Connect to Analog Globals */                                                  
#define nMI_AG                     (* (reg8 *) nMI__AG)                       
/* Analog MUX bux enable */
#define nMI_AMUX                   (* (reg8 *) nMI__AMUX) 
/* Bidirectional Enable */                                                        
#define nMI_BIE                    (* (reg8 *) nMI__BIE)
/* Bit-mask for Aliased Register Access */
#define nMI_BIT_MASK               (* (reg8 *) nMI__BIT_MASK)
/* Bypass Enable */
#define nMI_BYP                    (* (reg8 *) nMI__BYP)
/* Port wide control signals */                                                   
#define nMI_CTL                    (* (reg8 *) nMI__CTL)
/* Drive Modes */
#define nMI_DM0                    (* (reg8 *) nMI__DM0) 
#define nMI_DM1                    (* (reg8 *) nMI__DM1)
#define nMI_DM2                    (* (reg8 *) nMI__DM2) 
/* Input Buffer Disable Override */
#define nMI_INP_DIS                (* (reg8 *) nMI__INP_DIS)
/* LCD Common or Segment Drive */
#define nMI_LCD_COM_SEG            (* (reg8 *) nMI__LCD_COM_SEG)
/* Enable Segment LCD */
#define nMI_LCD_EN                 (* (reg8 *) nMI__LCD_EN)
/* Slew Rate Control */
#define nMI_SLW                    (* (reg8 *) nMI__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define nMI_PRTDSI__CAPS_SEL       (* (reg8 *) nMI__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define nMI_PRTDSI__DBL_SYNC_IN    (* (reg8 *) nMI__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define nMI_PRTDSI__OE_SEL0        (* (reg8 *) nMI__PRTDSI__OE_SEL0) 
#define nMI_PRTDSI__OE_SEL1        (* (reg8 *) nMI__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define nMI_PRTDSI__OUT_SEL0       (* (reg8 *) nMI__PRTDSI__OUT_SEL0) 
#define nMI_PRTDSI__OUT_SEL1       (* (reg8 *) nMI__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define nMI_PRTDSI__SYNC_OUT       (* (reg8 *) nMI__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(nMI__SIO_CFG)
    #define nMI_SIO_HYST_EN        (* (reg8 *) nMI__SIO_HYST_EN)
    #define nMI_SIO_REG_HIFREQ     (* (reg8 *) nMI__SIO_REG_HIFREQ)
    #define nMI_SIO_CFG            (* (reg8 *) nMI__SIO_CFG)
    #define nMI_SIO_DIFF           (* (reg8 *) nMI__SIO_DIFF)
#endif /* (nMI__SIO_CFG) */

/* Interrupt Registers */
#if defined(nMI__INTSTAT)
    #define nMI_INTSTAT            (* (reg8 *) nMI__INTSTAT)
    #define nMI_SNAP               (* (reg8 *) nMI__SNAP)
    
	#define nMI_0_INTTYPE_REG 		(* (reg8 *) nMI__0__INTTYPE)
#endif /* (nMI__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_nMI_H */


/* [] END OF FILE */
