/*******************************************************************************
* File Name: IORESET.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IORESET_H) /* Pins IORESET_H */
#define CY_PINS_IORESET_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "IORESET_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 IORESET__PORT == 15 && ((IORESET__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    IORESET_Write(uint8 value);
void    IORESET_SetDriveMode(uint8 mode);
uint8   IORESET_ReadDataReg(void);
uint8   IORESET_Read(void);
void    IORESET_SetInterruptMode(uint16 position, uint16 mode);
uint8   IORESET_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the IORESET_SetDriveMode() function.
     *  @{
     */
        #define IORESET_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define IORESET_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define IORESET_DM_RES_UP          PIN_DM_RES_UP
        #define IORESET_DM_RES_DWN         PIN_DM_RES_DWN
        #define IORESET_DM_OD_LO           PIN_DM_OD_LO
        #define IORESET_DM_OD_HI           PIN_DM_OD_HI
        #define IORESET_DM_STRONG          PIN_DM_STRONG
        #define IORESET_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define IORESET_MASK               IORESET__MASK
#define IORESET_SHIFT              IORESET__SHIFT
#define IORESET_WIDTH              1u

/* Interrupt constants */
#if defined(IORESET__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in IORESET_SetInterruptMode() function.
     *  @{
     */
        #define IORESET_INTR_NONE      (uint16)(0x0000u)
        #define IORESET_INTR_RISING    (uint16)(0x0001u)
        #define IORESET_INTR_FALLING   (uint16)(0x0002u)
        #define IORESET_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define IORESET_INTR_MASK      (0x01u) 
#endif /* (IORESET__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define IORESET_PS                     (* (reg8 *) IORESET__PS)
/* Data Register */
#define IORESET_DR                     (* (reg8 *) IORESET__DR)
/* Port Number */
#define IORESET_PRT_NUM                (* (reg8 *) IORESET__PRT) 
/* Connect to Analog Globals */                                                  
#define IORESET_AG                     (* (reg8 *) IORESET__AG)                       
/* Analog MUX bux enable */
#define IORESET_AMUX                   (* (reg8 *) IORESET__AMUX) 
/* Bidirectional Enable */                                                        
#define IORESET_BIE                    (* (reg8 *) IORESET__BIE)
/* Bit-mask for Aliased Register Access */
#define IORESET_BIT_MASK               (* (reg8 *) IORESET__BIT_MASK)
/* Bypass Enable */
#define IORESET_BYP                    (* (reg8 *) IORESET__BYP)
/* Port wide control signals */                                                   
#define IORESET_CTL                    (* (reg8 *) IORESET__CTL)
/* Drive Modes */
#define IORESET_DM0                    (* (reg8 *) IORESET__DM0) 
#define IORESET_DM1                    (* (reg8 *) IORESET__DM1)
#define IORESET_DM2                    (* (reg8 *) IORESET__DM2) 
/* Input Buffer Disable Override */
#define IORESET_INP_DIS                (* (reg8 *) IORESET__INP_DIS)
/* LCD Common or Segment Drive */
#define IORESET_LCD_COM_SEG            (* (reg8 *) IORESET__LCD_COM_SEG)
/* Enable Segment LCD */
#define IORESET_LCD_EN                 (* (reg8 *) IORESET__LCD_EN)
/* Slew Rate Control */
#define IORESET_SLW                    (* (reg8 *) IORESET__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define IORESET_PRTDSI__CAPS_SEL       (* (reg8 *) IORESET__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define IORESET_PRTDSI__DBL_SYNC_IN    (* (reg8 *) IORESET__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define IORESET_PRTDSI__OE_SEL0        (* (reg8 *) IORESET__PRTDSI__OE_SEL0) 
#define IORESET_PRTDSI__OE_SEL1        (* (reg8 *) IORESET__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define IORESET_PRTDSI__OUT_SEL0       (* (reg8 *) IORESET__PRTDSI__OUT_SEL0) 
#define IORESET_PRTDSI__OUT_SEL1       (* (reg8 *) IORESET__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define IORESET_PRTDSI__SYNC_OUT       (* (reg8 *) IORESET__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(IORESET__SIO_CFG)
    #define IORESET_SIO_HYST_EN        (* (reg8 *) IORESET__SIO_HYST_EN)
    #define IORESET_SIO_REG_HIFREQ     (* (reg8 *) IORESET__SIO_REG_HIFREQ)
    #define IORESET_SIO_CFG            (* (reg8 *) IORESET__SIO_CFG)
    #define IORESET_SIO_DIFF           (* (reg8 *) IORESET__SIO_DIFF)
#endif /* (IORESET__SIO_CFG) */

/* Interrupt Registers */
#if defined(IORESET__INTSTAT)
    #define IORESET_INTSTAT            (* (reg8 *) IORESET__INTSTAT)
    #define IORESET_SNAP               (* (reg8 *) IORESET__SNAP)
    
	#define IORESET_0_INTTYPE_REG 		(* (reg8 *) IORESET__0__INTTYPE)
#endif /* (IORESET__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_IORESET_H */


/* [] END OF FILE */
