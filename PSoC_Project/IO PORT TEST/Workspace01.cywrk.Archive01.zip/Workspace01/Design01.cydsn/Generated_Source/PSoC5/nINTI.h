/*******************************************************************************
* File Name: nINTI.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_nINTI_H) /* Pins nINTI_H */
#define CY_PINS_nINTI_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "nINTI_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 nINTI__PORT == 15 && ((nINTI__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    nINTI_Write(uint8 value);
void    nINTI_SetDriveMode(uint8 mode);
uint8   nINTI_ReadDataReg(void);
uint8   nINTI_Read(void);
void    nINTI_SetInterruptMode(uint16 position, uint16 mode);
uint8   nINTI_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the nINTI_SetDriveMode() function.
     *  @{
     */
        #define nINTI_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define nINTI_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define nINTI_DM_RES_UP          PIN_DM_RES_UP
        #define nINTI_DM_RES_DWN         PIN_DM_RES_DWN
        #define nINTI_DM_OD_LO           PIN_DM_OD_LO
        #define nINTI_DM_OD_HI           PIN_DM_OD_HI
        #define nINTI_DM_STRONG          PIN_DM_STRONG
        #define nINTI_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define nINTI_MASK               nINTI__MASK
#define nINTI_SHIFT              nINTI__SHIFT
#define nINTI_WIDTH              1u

/* Interrupt constants */
#if defined(nINTI__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in nINTI_SetInterruptMode() function.
     *  @{
     */
        #define nINTI_INTR_NONE      (uint16)(0x0000u)
        #define nINTI_INTR_RISING    (uint16)(0x0001u)
        #define nINTI_INTR_FALLING   (uint16)(0x0002u)
        #define nINTI_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define nINTI_INTR_MASK      (0x01u) 
#endif /* (nINTI__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define nINTI_PS                     (* (reg8 *) nINTI__PS)
/* Data Register */
#define nINTI_DR                     (* (reg8 *) nINTI__DR)
/* Port Number */
#define nINTI_PRT_NUM                (* (reg8 *) nINTI__PRT) 
/* Connect to Analog Globals */                                                  
#define nINTI_AG                     (* (reg8 *) nINTI__AG)                       
/* Analog MUX bux enable */
#define nINTI_AMUX                   (* (reg8 *) nINTI__AMUX) 
/* Bidirectional Enable */                                                        
#define nINTI_BIE                    (* (reg8 *) nINTI__BIE)
/* Bit-mask for Aliased Register Access */
#define nINTI_BIT_MASK               (* (reg8 *) nINTI__BIT_MASK)
/* Bypass Enable */
#define nINTI_BYP                    (* (reg8 *) nINTI__BYP)
/* Port wide control signals */                                                   
#define nINTI_CTL                    (* (reg8 *) nINTI__CTL)
/* Drive Modes */
#define nINTI_DM0                    (* (reg8 *) nINTI__DM0) 
#define nINTI_DM1                    (* (reg8 *) nINTI__DM1)
#define nINTI_DM2                    (* (reg8 *) nINTI__DM2) 
/* Input Buffer Disable Override */
#define nINTI_INP_DIS                (* (reg8 *) nINTI__INP_DIS)
/* LCD Common or Segment Drive */
#define nINTI_LCD_COM_SEG            (* (reg8 *) nINTI__LCD_COM_SEG)
/* Enable Segment LCD */
#define nINTI_LCD_EN                 (* (reg8 *) nINTI__LCD_EN)
/* Slew Rate Control */
#define nINTI_SLW                    (* (reg8 *) nINTI__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define nINTI_PRTDSI__CAPS_SEL       (* (reg8 *) nINTI__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define nINTI_PRTDSI__DBL_SYNC_IN    (* (reg8 *) nINTI__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define nINTI_PRTDSI__OE_SEL0        (* (reg8 *) nINTI__PRTDSI__OE_SEL0) 
#define nINTI_PRTDSI__OE_SEL1        (* (reg8 *) nINTI__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define nINTI_PRTDSI__OUT_SEL0       (* (reg8 *) nINTI__PRTDSI__OUT_SEL0) 
#define nINTI_PRTDSI__OUT_SEL1       (* (reg8 *) nINTI__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define nINTI_PRTDSI__SYNC_OUT       (* (reg8 *) nINTI__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(nINTI__SIO_CFG)
    #define nINTI_SIO_HYST_EN        (* (reg8 *) nINTI__SIO_HYST_EN)
    #define nINTI_SIO_REG_HIFREQ     (* (reg8 *) nINTI__SIO_REG_HIFREQ)
    #define nINTI_SIO_CFG            (* (reg8 *) nINTI__SIO_CFG)
    #define nINTI_SIO_DIFF           (* (reg8 *) nINTI__SIO_DIFF)
#endif /* (nINTI__SIO_CFG) */

/* Interrupt Registers */
#if defined(nINTI__INTSTAT)
    #define nINTI_INTSTAT            (* (reg8 *) nINTI__INTSTAT)
    #define nINTI_SNAP               (* (reg8 *) nINTI__SNAP)
    
	#define nINTI_0_INTTYPE_REG 		(* (reg8 *) nINTI__0__INTTYPE)
#endif /* (nINTI__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_nINTI_H */


/* [] END OF FILE */
