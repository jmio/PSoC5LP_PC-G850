/*******************************************************************************
* File Name: nIOREQ.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_nIOREQ_H) /* Pins nIOREQ_H */
#define CY_PINS_nIOREQ_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "nIOREQ_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 nIOREQ__PORT == 15 && ((nIOREQ__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    nIOREQ_Write(uint8 value);
void    nIOREQ_SetDriveMode(uint8 mode);
uint8   nIOREQ_ReadDataReg(void);
uint8   nIOREQ_Read(void);
void    nIOREQ_SetInterruptMode(uint16 position, uint16 mode);
uint8   nIOREQ_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the nIOREQ_SetDriveMode() function.
     *  @{
     */
        #define nIOREQ_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define nIOREQ_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define nIOREQ_DM_RES_UP          PIN_DM_RES_UP
        #define nIOREQ_DM_RES_DWN         PIN_DM_RES_DWN
        #define nIOREQ_DM_OD_LO           PIN_DM_OD_LO
        #define nIOREQ_DM_OD_HI           PIN_DM_OD_HI
        #define nIOREQ_DM_STRONG          PIN_DM_STRONG
        #define nIOREQ_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define nIOREQ_MASK               nIOREQ__MASK
#define nIOREQ_SHIFT              nIOREQ__SHIFT
#define nIOREQ_WIDTH              1u

/* Interrupt constants */
#if defined(nIOREQ__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in nIOREQ_SetInterruptMode() function.
     *  @{
     */
        #define nIOREQ_INTR_NONE      (uint16)(0x0000u)
        #define nIOREQ_INTR_RISING    (uint16)(0x0001u)
        #define nIOREQ_INTR_FALLING   (uint16)(0x0002u)
        #define nIOREQ_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define nIOREQ_INTR_MASK      (0x01u) 
#endif /* (nIOREQ__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define nIOREQ_PS                     (* (reg8 *) nIOREQ__PS)
/* Data Register */
#define nIOREQ_DR                     (* (reg8 *) nIOREQ__DR)
/* Port Number */
#define nIOREQ_PRT_NUM                (* (reg8 *) nIOREQ__PRT) 
/* Connect to Analog Globals */                                                  
#define nIOREQ_AG                     (* (reg8 *) nIOREQ__AG)                       
/* Analog MUX bux enable */
#define nIOREQ_AMUX                   (* (reg8 *) nIOREQ__AMUX) 
/* Bidirectional Enable */                                                        
#define nIOREQ_BIE                    (* (reg8 *) nIOREQ__BIE)
/* Bit-mask for Aliased Register Access */
#define nIOREQ_BIT_MASK               (* (reg8 *) nIOREQ__BIT_MASK)
/* Bypass Enable */
#define nIOREQ_BYP                    (* (reg8 *) nIOREQ__BYP)
/* Port wide control signals */                                                   
#define nIOREQ_CTL                    (* (reg8 *) nIOREQ__CTL)
/* Drive Modes */
#define nIOREQ_DM0                    (* (reg8 *) nIOREQ__DM0) 
#define nIOREQ_DM1                    (* (reg8 *) nIOREQ__DM1)
#define nIOREQ_DM2                    (* (reg8 *) nIOREQ__DM2) 
/* Input Buffer Disable Override */
#define nIOREQ_INP_DIS                (* (reg8 *) nIOREQ__INP_DIS)
/* LCD Common or Segment Drive */
#define nIOREQ_LCD_COM_SEG            (* (reg8 *) nIOREQ__LCD_COM_SEG)
/* Enable Segment LCD */
#define nIOREQ_LCD_EN                 (* (reg8 *) nIOREQ__LCD_EN)
/* Slew Rate Control */
#define nIOREQ_SLW                    (* (reg8 *) nIOREQ__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define nIOREQ_PRTDSI__CAPS_SEL       (* (reg8 *) nIOREQ__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define nIOREQ_PRTDSI__DBL_SYNC_IN    (* (reg8 *) nIOREQ__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define nIOREQ_PRTDSI__OE_SEL0        (* (reg8 *) nIOREQ__PRTDSI__OE_SEL0) 
#define nIOREQ_PRTDSI__OE_SEL1        (* (reg8 *) nIOREQ__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define nIOREQ_PRTDSI__OUT_SEL0       (* (reg8 *) nIOREQ__PRTDSI__OUT_SEL0) 
#define nIOREQ_PRTDSI__OUT_SEL1       (* (reg8 *) nIOREQ__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define nIOREQ_PRTDSI__SYNC_OUT       (* (reg8 *) nIOREQ__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(nIOREQ__SIO_CFG)
    #define nIOREQ_SIO_HYST_EN        (* (reg8 *) nIOREQ__SIO_HYST_EN)
    #define nIOREQ_SIO_REG_HIFREQ     (* (reg8 *) nIOREQ__SIO_REG_HIFREQ)
    #define nIOREQ_SIO_CFG            (* (reg8 *) nIOREQ__SIO_CFG)
    #define nIOREQ_SIO_DIFF           (* (reg8 *) nIOREQ__SIO_DIFF)
#endif /* (nIOREQ__SIO_CFG) */

/* Interrupt Registers */
#if defined(nIOREQ__INTSTAT)
    #define nIOREQ_INTSTAT            (* (reg8 *) nIOREQ__INTSTAT)
    #define nIOREQ_SNAP               (* (reg8 *) nIOREQ__SNAP)
    
	#define nIOREQ_0_INTTYPE_REG 		(* (reg8 *) nIOREQ__0__INTTYPE)
#endif /* (nIOREQ__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_nIOREQ_H */


/* [] END OF FILE */
