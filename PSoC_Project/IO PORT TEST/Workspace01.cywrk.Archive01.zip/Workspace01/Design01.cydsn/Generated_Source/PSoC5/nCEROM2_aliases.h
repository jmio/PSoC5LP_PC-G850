/*******************************************************************************
* File Name: nCEROM2.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_nCEROM2_ALIASES_H) /* Pins nCEROM2_ALIASES_H */
#define CY_PINS_nCEROM2_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define nCEROM2_0			(nCEROM2__0__PC)
#define nCEROM2_0_INTR	((uint16)((uint16)0x0001u << nCEROM2__0__SHIFT))

#define nCEROM2_INTR_ALL	 ((uint16)(nCEROM2_0_INTR))

#endif /* End Pins nCEROM2_ALIASES_H */


/* [] END OF FILE */
