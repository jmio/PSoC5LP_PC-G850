/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include "stdio.h"

struct IntrBuf {
    uint16 addr;
    uint8 data;
    uint8 bus1;
    uint8 bus2;
} ;

#define RD      (0x01)
#define WR      (0x02)
#define MREQ    (0x04)
#define CEROM2  (0x08)
#define M1      (0x10)
#define IOREQ   (0x20)

#define WAIT    (0x01)
#define BANK1   (0x08)
#define IORESET (0x10)
#define INTI    (0x20)
#define CERAM2  (0x40)
#define BANK0   (0x80)



#define MAXTABLE (0x1000)

extern struct IntrBuf Atable[MAXTABLE];
extern uint Atable_ctr;
extern uint Fetch ;
extern uint LimitMode ;

/* [] END OF FILE */
